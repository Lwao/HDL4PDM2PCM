#define display (short*) 0x0002000

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

int main () 
{
	FILE *f;

	f = fopen("test", "a");
	fprintf(f, "Hello world!");
	fclose(f);

	return 0;
}