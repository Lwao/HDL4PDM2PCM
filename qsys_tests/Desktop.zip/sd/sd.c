#include <altera_up_sd_card_avalon_interface.h>

	int main(void)
	{
	    alt_up_sd_card_dev *device_reference = NULL;
	    int connected = 0;  
	    
	    device_reference = alt_up_sd_card_open_dev(SD_CARD_INTERFACE_NAME);
	    if (device_reference != NULL)
	    {
		printf("Initialized. Waiting for SD card...\n");
		while(1)
		{
		    if ((connected == 0) && (alt_up_sd_card_is_Present()))
		    {
		        printf("Card connected.\n");
		        if (alt_up_sd_card_is_FAT16())
		        {
			    printf("FAT16 file system detected.\n");
			    
			    printf("Looking for first file.\n");
			    char * firstFile = "filenameunchanged";
			    alt_up_sd_card_find_first(".", firstFile);
			    printf("Volume Name: '%s'\n\n", firstFile);
			
			    short file;
			    while((file = alt_up_sd_card_find_next(firstFile)) != -1)
			    {
			        int contentCount = 0;
			        printf("===========================\n");
			        printf("Found file: '%s'\n", firstFile);                        
			        
			        short fileHandle = alt_up_sd_card_fopen(firstFile,false);
			        printf("File handle: %i\n", fileHandle);
			        
			        printf("Contents:\n");
			        short int readCharacter;
			        while ((readCharacter = alt_up_sd_card_read(fileHandle)) != -1)
			        {
			            printf("%c", readCharacter);
			            ++contentCount;
			        }
			        printf("\nContent size: %i", contentCount);
			        printf("\n===========================\n\n");                  
			    }
		        } 
		        else 
		        {
			    printf("Unknown file system.\n");
		        }
		        
		        connected = 1;
		    } 
		    else if ((connected == 1) && (alt_up_sd_card_is_Present() == false)) 
		    {
		        printf("Card disconnected.\n");
		        connected = 0;
		    }
		}
	    }
	    else
	    {
		printf("Initialization failed.\n");
	    }
	} 